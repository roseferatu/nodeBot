// Test script for AI Provider
import { askCommand, chatCommand } from './server/lib/aiProvider.js';

async function testAiProviders() {
  console.log("Testing AI Providers...");
  
  try {
    // Test with a simple question
    const response1 = await askCommand("What is the capital of France?");
    console.log("\nTest 1 - Simple question:");
    console.log(response1);
    
    // Test with a complex question
    const response2 = await askCommand("Can you explain how quantum computing works in simple terms?");
    console.log("\nTest 2 - Complex question:");
    console.log(response2);
    
    // Test chat continuation
    const context = [
      { 
        id: 1,
        server_id: "test-server-id",
        channel_id: "test-channel-id",
        user_id: "test-user-id",
        username: "TestUser",
        message: "Hello, who are you?",
        response: "I'm an AI assistant created to help answer your questions and have conversations.",
        command: "chat",
        created_at: new Date(),
        is_error: false,
        error_message: null
      }
    ];
    
    const response3 = await chatCommand("Tell me more about what you can do", context);
    console.log("\nTest 3 - Chat with context:");
    console.log(response3);
    
    console.log("\nAll tests completed successfully!");
  } catch (error) {
    console.error("Error during tests:", error);
  }
}

testAiProviders();