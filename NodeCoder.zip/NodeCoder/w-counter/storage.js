// storage.js - Persistent storage for W Counter data
const fs = require('fs');
const path = require('path');

const STORAGE_FILE = path.join(__dirname, 'counter-data.json');

// Default data structure
const defaultData = {
  serverCounters: {},
  serverTotalCounters: {}
};

/**
 * Load counter data from disk
 * @returns {Object} The loaded data or default data if file doesn't exist
 */
function loadData() {
  try {
    // Check if file exists
    if (fs.existsSync(STORAGE_FILE)) {
      const data = fs.readFileSync(STORAGE_FILE, 'utf8');
      return JSON.parse(data);
    } else {
      // Return default data if file doesn't exist
      return defaultData;
    }
  } catch (error) {
    console.error('Error loading counter data:', error);
    return defaultData;
  }
}

/**
 * Save counter data to disk
 * @param {Object} data The data to save
 */
function saveData(data) {
  try {
    fs.writeFileSync(STORAGE_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error('Error saving counter data:', error);
  }
}

/**
 * Save counter data periodically
 * @param {Object} serverCounters The channel counter data
 * @param {Object} serverTotalCounters The total counter data
 */
function setupAutosave(serverCounters, serverTotalCounters) {
  // Save data every 5 minutes
  setInterval(() => {
    const data = {
      serverCounters,
      serverTotalCounters
    };
    saveData(data);
    console.log('W Counter data autosaved');
  }, 5 * 60 * 1000); // 5 minutes

  // Save data when the process exits
  process.on('SIGINT', () => {
    const data = {
      serverCounters,
      serverTotalCounters
    };
    saveData(data);
    console.log('W Counter data saved before exit');
    process.exit(0);
  });
}

module.exports = {
  loadData,
  saveData,
  setupAutosave
};