[Start W Counter Bot]
command = "cd w-counter && node simple-bot.js"
is_persistent = true