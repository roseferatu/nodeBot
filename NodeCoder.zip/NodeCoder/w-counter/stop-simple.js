
// Stop script for the simplified W counter bot
const fs = require('fs');
const pidFile = './w-simple-pid.txt';

if (fs.existsSync(pidFile)) {
  const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
  console.log(`Attempting to stop simplified W Counter bot with PID: ${pid}...`);
  
  try {
    process.kill(pid);
    console.log(`Successfully stopped simplified W Counter bot with PID: ${pid}`);
  } catch (error) {
    console.log(`Failed to stop process: ${error.message}`);
  }
  
  fs.unlinkSync(pidFile);
} else {
  console.log('No PID file found. Bot may not be running.');
}
