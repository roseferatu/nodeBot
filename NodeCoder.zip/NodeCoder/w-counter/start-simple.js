// Script to start the simplified W counter bot
require('dotenv').config();
const fs = require('fs');
const { spawn } = require('child_process');
const pidFile = './w-simple-pid.txt';

console.log('Starting simplified W Counter bot...');

// First check if there's an existing process
let existingPid = null;
try {
  if (fs.existsSync(pidFile)) {
    existingPid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
    console.log(`Found existing simplified W Counter bot process (PID: ${existingPid}), attempting to terminate...`);
    
    try {
      // Try to kill the existing process
      process.kill(existingPid);
      console.log(`Terminated existing simplified W Counter bot process with PID: ${existingPid}`);
    } catch (error) {
      // If we can't kill it, it probably doesn't exist anymore
      console.log(`No process with PID ${existingPid} was running, proceeding with startup`);
    }
  }
} catch (error) {
  console.error('Error checking existing process:', error);
}

// Ensure the stop script exists
const stopContent = `
// Stop script for the simplified W counter bot
const fs = require('fs');
const pidFile = './w-simple-pid.txt';

if (fs.existsSync(pidFile)) {
  const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
  console.log(\`Attempting to stop simplified W Counter bot with PID: \${pid}...\`);
  
  try {
    process.kill(pid);
    console.log(\`Successfully stopped simplified W Counter bot with PID: \${pid}\`);
  } catch (error) {
    console.log(\`Failed to stop process: \${error.message}\`);
  }
  
  fs.unlinkSync(pidFile);
} else {
  console.log('No PID file found. Bot may not be running.');
}
`;

fs.writeFileSync('./stop-simple.js', stopContent);

// Start the bot with node
const botProcess = spawn('node', ['simple-bot.js'], {
  detached: true,
  stdio: 'inherit'
});

// Get the process ID and save it to the PID file
const pid = botProcess.pid;
fs.writeFileSync(pidFile, `${pid}`);
console.log(`Simplified W Counter bot started with PID: ${pid}`);

// Let it run independently of this process
botProcess.unref();