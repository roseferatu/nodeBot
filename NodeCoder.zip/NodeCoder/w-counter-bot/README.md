# W Counter Discord Bot

A simple Discord bot that counts the number of "W"s mentioned in your server's chat.

## Features

- Counts occurrences of the letter "W" in messages (case insensitive)
- Keeps a running count for each server
- Displays the count whenever a W is mentioned
- Provides slash commands to check or reset the counter

## Commands

- `/count` - Shows the current W count for this server
- `/reset` - Resets the W counter to zero (for admins to use)

## Setup

1. Clone this repository
2. Install dependencies with `npm install`
3. Create a `.env` file based on `.env.example` and add your Discord bot token and application ID
4. Build the TypeScript files with `npm run build`
5. Start the bot with `npm start`

## Development

- Start in development mode: `npm run dev` (uses ts-node)
- Build the project: `npm run build`
- Watch mode (for development): `npm run watch`

## Requirements

- Node.js v16.9.0 or higher
- Discord.js v14
- A Discord bot token (create one at https://discord.com/developers/applications)

## Bot Permissions

The bot requires the following permissions:
- Read Messages/View Channels
- Send Messages
- Use Slash Commands

## How to Add to Your Server

1. Create a bot application in the [Discord Developer Portal](https://discord.com/developers/applications)
2. Generate an invite link with the required permissions
3. Invite the bot to your server using the generated link
4. Run the bot code on your server or hosting provider

## Register Commands

To register slash commands with Discord, run:

```
npx ts-node src/deploy-commands.ts
```