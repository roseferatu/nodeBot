import { 
  Client, 
  Events, 
  GatewayIntentBits, 
  Message, 
  TextChannel,
  ChannelType
} from 'discord.js';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Initialize counters for each server
const serverCounters: { [serverId: string]: number } = {};

// Create a new Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// When the client is ready, run this code
client.once(Events.ClientReady, (readyClient) => {
  console.log(`Bot is ready! Logged in as ${readyClient.user.tag}`);
});

// Listen for messages
client.on(Events.MessageCreate, async (message: Message) => {
  // Ignore messages from bots to prevent infinite loops
  if (message.author.bot) return;

  // Get the server ID
  const serverId = message.guild?.id;
  if (!serverId) return; // Skip DMs or messages not in a server

  // Initialize counter for this server if it doesn't exist
  if (!serverCounters[serverId]) {
    serverCounters[serverId] = 0;
  }

  // Check if the message contains 'w' (case insensitive)
  const messageContent = message.content.toLowerCase();
  if (messageContent.includes('w')) {
    // Count the number of w's in the message
    const wCount = (messageContent.match(/w/gi) || []).length;
    
    // Increment the server counter
    serverCounters[serverId] += wCount;
    
    // Send a message with the updated count
    try {
      // Check if it's a text-based channel
      if (message.channel.type === ChannelType.GuildText || 
          message.channel.type === ChannelType.DM ||
          message.channel.type === ChannelType.GuildPublicThread ||
          message.channel.type === ChannelType.GuildPrivateThread) {
        await message.channel.send(`${serverCounters[serverId]} W's in chat`);
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  }
});

// Handle errors
client.on(Events.Error, (error) => {
  console.error('Discord client error:', error);
});

// Login to Discord with your app's token
client.login(process.env.DISCORD_TOKEN)
  .catch(error => {
    console.error('Error logging in:', error);
  });

// Add a simple process termination handler
process.on('SIGINT', () => {
  console.log('Bot is shutting down...');
  client.destroy();
  process.exit(0);
});

// Add commands
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;

  // Reset command to zero out the W counter
  if (commandName === 'reset') {
    const serverId = interaction.guild?.id;
    if (serverId) {
      serverCounters[serverId] = 0;
      await interaction.reply('W counter has been reset to 0');
    }
  }

  // Count command to show the current W count
  if (commandName === 'count') {
    const serverId = interaction.guild?.id;
    if (serverId) {
      const count = serverCounters[serverId] || 0;
      await interaction.reply(`Current count: ${count} W's`);
    }
  }
});