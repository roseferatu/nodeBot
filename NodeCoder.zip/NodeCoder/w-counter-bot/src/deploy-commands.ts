import { REST, Routes } from 'discord.js';
import * as dotenv from 'dotenv';
import * as process from 'process';

// Load environment variables
dotenv.config();

const commands = [
  {
    name: 'reset',
    description: 'Reset the W counter to zero',
  },
  {
    name: 'count',
    description: 'Show the current W count',
  },
];

// Create and configure REST instance
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN || '');

// Deploy commands function
async function deployCommands() {
  try {
    console.log('Started refreshing application (/) commands.');

    // The put method is used to fully refresh all commands
    const data = await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID || ''),
      { body: commands },
    );

    console.log(`Successfully reloaded application (/) commands.`);
  } catch (error) {
    console.error(error);
  }
}

// Execute the function
deployCommands();