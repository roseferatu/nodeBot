// global.d.ts
declare global {
  var wCounterInitialized: boolean;
}

export {};